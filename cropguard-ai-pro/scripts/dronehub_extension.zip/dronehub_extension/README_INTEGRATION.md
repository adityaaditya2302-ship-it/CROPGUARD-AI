# CropGuard AI — Drone Hub Extension — Integration Guide

This package is **additive**. It doesn't touch your existing `models.py`
or `app.py` classes — you add a few lines, nothing gets removed or
renamed. If anything goes wrong, deleting the added lines + this
folder returns you to exactly where you started.

## What's inside

```
drone_extension/
  models_drone_ext.py    New DB tables: DroneHubMission, DroneHubTelemetryLog, DroneHubReport
  routes_drone.py         Flask Blueprint: all /api/dronehub/... routes
  simulated_telemetry.py  Phase 1-3: fake but realistic telemetry (no hardware needed)
  mavlink_adapter.py      Phase 4: real MAVLink connection (untested — needs SITL/hardware)
  dji_adapter.py          Phase 5: DJI interface stub (needs DJI enterprise account — see file)
  ai_mission_generator.py Real, working grid-path + spray-param generator (geometry only, no deps)
  report_generator.py     JSON/CSV always work; PDF needs `pip install reportlab`
templates/
  drone_connection.html   The dashboard page
static/js/drone_connection.js
static/css/drone_connection.css
requirements_addon.txt
```

## Step 1 — Copy files into your project

Copy the whole `drone_extension/` folder into your project root
(next to `app.py` and `models.py`), and merge the `templates/` and
`static/` folders into your existing ones (they only add new files,
`drone_connection.html`, `drone_connection.js`, `drone_connection.css`
— nothing overwrites your existing templates).

```powershell
# from inside your project root
Copy-Item -Recurse .\dronehub_extension\drone_extension .\
Copy-Item .\dronehub_extension\templates\drone_connection.html .\templates\
Copy-Item .\dronehub_extension\static\js\drone_connection.js .\static\js\
Copy-Item .\dronehub_extension\static\css\drone_connection.css .\static\css\
```

(Adjust paths if your `static`/`templates` folders are laid out
differently — check with `Get-ChildItem` first.)

## Step 2 — Register the blueprint in `app.py`

Add these two lines near your other imports/route registrations in
`app.py` (does not remove or change any existing line):

```python
from drone_extension.routes_drone import drone_bp
app.register_blueprint(drone_bp)
```

That's it — every new route lives under `/api/dronehub/...`, which
cannot collide with your existing `/api/drone/...` routes.

## Step 3 — Create the new tables

The new models import `db` from your existing `models.py`, so they
share the same database file. Just make sure `models_drone_ext.py`
gets imported once before `db.create_all()` runs — easiest way is to
add one import line wherever your `app.py` already does
`db.create_all()`:

```python
from drone_extension.models_drone_ext import DroneHubMission, DroneHubTelemetryLog, DroneHubReport
```

Then run the app once — Flask-SQLAlchemy will create the three new
tables (`dronehub_missions`, `dronehub_telemetry_log`,
`dronehub_reports`) alongside your existing ones. **No existing table
is touched.**

## Step 4 — Link it from your nav (optional)

Add a link anywhere in your existing nav/sidebar template:

```html
<a href="/api/dronehub/dashboard">Drone Connection</a>
```

## Step 5 — Install optional extras

```powershell
pip install -r requirements_addon.txt --break-system-packages
```

(`reportlab` for PDF reports, `pymavlink` for real hardware later —
skip either if you don't need it yet; routes degrade gracefully.)

## Step 6 — Verify nothing broke

```powershell
python app.py
```

Checklist:
1. App starts with no import errors.
2. Your existing pages (scan history, farm fields, tasks, etc.) still load.
3. Visit `http://localhost:5000/api/dronehub/dashboard` — new dashboard loads.
4. Click "Scan for Drones" → "Connect" on the demo drone → telemetry
   panel starts updating every second (simulated data).
5. Draw a boundary on the map (polygon tool, top-right of map) →
   "Generate AI Mission" → mission summary appears.
6. Start → Complete + Report → a report JSON appears at the bottom.

If step 1 or 2 fails, **stop and don't proceed** — paste the traceback
and we'll fix the integration before doing anything else. Steps 3-6
failing is lower risk (isolated to the new feature) but still worth
fixing before building further.

## Roadmap status

| Phase | Status |
|---|---|
| 1. Detection + connection UI, live telemetry (simulated) | ✅ Included, working today |
| 2. Mission planner (map draw, AI-generated grid path + spray params) | ✅ Included, working today |
| 3. Mission execution controls + reports (JSON/CSV/PDF) | ✅ Included, working today |
| 4. Real MAVLink hardware (ArduPilot/PX4) | ⚠️ Scaffolded in `mavlink_adapter.py` — **untested**, needs SITL or real flight controller to verify |
| 5. Real DJI hardware | ⚠️ Interface stub only in `dji_adapter.py` — DJI requires an enterprise developer account + Dock hardware; cannot be made to work from code alone |

## Switching from simulated to real telemetry later

In `drone_extension/routes_drone.py`, near the top:

```python
from . import simulated_telemetry as drone_adapter
# swap to:
# from . import mavlink_adapter as drone_adapter
```

Change that one import once you've tested `mavlink_adapter.py`
against SITL or real hardware directly (not just through this app).
